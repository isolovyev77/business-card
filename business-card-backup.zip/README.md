# Сайт-визитка Ивана Соловьева

Статический одностраничный сайт-визитка с информацией об энтузиасте ИИ, промт-инжиниринга и вайб-кодинга.

## 🚀 Быстрый старт

### Локальный запуск

Запустите локальный сервер из корня репозитория:

```bash
python3 -m http.server 8000
```

Откройте в браузере: [http://localhost:8000](http://localhost:8000)

### Структура проекта

```
.
├── index.html              # Главная страница
├── styles.css              # Стили сайта
├── script.js               # Интерактивность и переключатель темы
├── assets/
│   ├── favicon.svg         # Иконка сайта
│   └── ivan-solovyev.vcf   # vCard контакт
└── README.md
```

## 🌐 Публикация на GitHub Pages

### 1. Закоммитьте все файлы

Убедитесь, что все изменения добавлены в репозиторий:

```bash
git add .
git commit -m "Initial commit: business card website"
git push origin main
```

### 2. Включите GitHub Pages

1. Откройте репозиторий на GitHub: `https://github.com/isolovyev77/business-card`
2. Перейдите в **Settings** (Настройки) → **Pages** (в левом меню)
3. В разделе **Source** (Источник):
   - **Branch**: выберите `main`
   - **Folder**: выберите `/ (root)`
4. Нажмите **Save**

### 3. Дождитесь публикации

GitHub Pages автоматически опубликует сайт через 1-2 минуты.  
Ваш сайт будет доступен по адресу:

**https://isolovyev77.github.io/business-card/**

## 🔄 Обновление сайта

Для обновления содержимого сайта:

1. Внесите изменения в файлы (`index.html`, `styles.css`, `script.js`)
2. Закоммитьте и отправьте изменения:

```bash
git add .
git commit -m "Update website content"
git push origin main
```

3. GitHub Pages автоматически обновит сайт в течение нескольких минут

## ✨ Возможности

- 🎨 Минималистичный современный дизайн
- 🌓 Переключатель темы (светлая/темная) с сохранением в localStorage
- 📱 Полностью адаптивная верстка
- 🚀 Без внешних зависимостей (чистые HTML/CSS/JS)
- 📇 Скачивание vCard контакта
- 🔍 SEO-оптимизация и OpenGraph meta-теги

## 📝 Контакты

- Telegram: [@isolovyev](https://t.me/isolovyev)
- Instagram: [@isolovyev](https://instagram.com/isolovyev)
- Email: [isolovyev@mail.ru](mailto:isolovyev@mail.ru)

---

© 2026 Иван Соловьев
